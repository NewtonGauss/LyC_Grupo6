#ifndef TERCETOS_H
#define TERCETOS_H

#include <stdio.h>

typedef enum {
	TERC_IDX, /* indice que representa el terceto a referenciar */
	TERC_OP, /* srting que representa el operador a poner */
	TERC_VAL, /* string que representa el valor a poner */
	TERC_VOID, /* entry vacia */
	TERC_SZ /* indica el tamaño del enum */
} TercType;

typedef struct {
	void *data; /* TODO: cambiar por un union type */
	TercType type;
} TercEntry;

typedef struct {
	TercEntry first,
						second,
						third;
} TercEntries;

#define LIST_SZ 1024
typedef struct {
	TercEntries entries[LIST_SZ];
	int current;
} _terceto;

typedef _terceto* Terceto;

Terceto NewTerceto(void);
int AddTerceto(Terceto t, TercEntry e1, TercEntry e2, TercEntry e3);
void FillVoid(Terceto t, int idxToFill, int branchIdx);
int CurrentIndex(Terceto t);
char *Printable(Terceto t, int idx);

#endif
